// Mining Wallet Manager
class MiningWalletManager {
    constructor() {
        this.config = this.loadConfig();
        this.miningInterval = null;
        this.isActive = false;
    }

    // Load configuration from JSON file
    loadConfig() {
        try {
            const fs = require('fs');
            const data = fs.readFileSync('mining_wallet/wallet_config.json', 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('Error loading mining config:', error);
            return this.getDefaultConfig();
        }
    }

    // Save configuration to JSON file
    saveConfig() {
        try {
            const fs = require('fs');
            fs.writeFileSync('mining_wallet/wallet_config.json', JSON.stringify(this.config, null, 2));
            return true;
        } catch (error) {
            console.error('Error saving mining config:', error);
            return false;
        }
    }

    // Get default configuration
    getDefaultConfig() {
        return {
            mining_wallet: {
                enabled: false,
                wallet_address: '',
                balance: 100,
                currency: 'GBP',
                mining_rate: 0.5,
                update_interval: 300,
                last_update: Date.now(),
                supported_cryptos: ['BTC', 'ETH', 'USDT', 'USDC', 'BNB'],
                auto_withdrawal: {
                    enabled: false,
                    threshold: 1000,
                    target_address: ''
                }
            },
            transaction_history: [],
            mining_stats: {
                total_mined: 0,
                total_withdrawals: 0,
                start_date: null,
                active_minutes: 0
            }
        };
    }

    // Start mining
    startMining() {
        if (this.isActive) {
            console.log('Mining is already active');
            return false;
        }

        this.isActive = true;
        this.config.mining_wallet.enabled = true;
        this.config.mining_wallet.last_update = Date.now();
        
        if (!this.config.mining_stats.start_date) {
            this.config.mining_stats.start_date = new Date().toISOString();
        }

        this.saveConfig();
        this.startMiningLoop();
        console.log('Mining started successfully');
        return true;
    }

    // Stop mining
    stopMining() {
        if (!this.isActive) {
            console.log('Mining is not active');
            return false;
        }

        this.isActive = false;
        this.config.mining_wallet.enabled = false;
        
        if (this.miningInterval) {
            clearInterval(this.miningInterval);
            this.miningInterval = null;
        }

        this.saveConfig();
        console.log('Mining stopped successfully');
        return true;
    }

    // Start mining loop
    startMiningLoop() {
        const intervalMs = this.config.mining_wallet.update_interval * 1000; // Convert to milliseconds
        
        this.miningInterval = setInterval(() => {
            this.mine();
        }, intervalMs);
    }

    // Mine function - increases balance
    mine() {
        if (!this.isActive) {
            return;
        }

        const now = Date.now();
        const lastUpdate = this.config.mining_wallet.last_update || now;
        const timeDiff = (now - lastUpdate) / 1000; // Convert to seconds
        const intervals = Math.floor(timeDiff / this.config.mining_wallet.update_interval);

        if (intervals > 0) {
            const increase = intervals * this.config.mining_wallet.mining_rate;
            
            // Update balance
            this.config.mining_wallet.balance += increase;
            this.config.mining_wallet.last_update = now;
            
            // Update stats
            this.config.mining_stats.total_mined += increase;
            this.config.mining_stats.active_minutes += (intervals * this.config.mining_wallet.update_interval) / 60;
            
            // Add to transaction history
            this.addTransaction('mining', increase, 'Mining reward');
            
            // Check auto-withdrawal
            this.checkAutoWithdrawal();
            
            // Save config
            this.saveConfig();
            
            console.log(`Mined £${increase.toFixed(2)} | Total: £${this.config.mining_wallet.balance.toFixed(2)}`);
        }
    }

    // Add transaction to history
    addTransaction(type, amount, description) {
        const transaction = {
            id: Date.now(),
            type: type,
            amount: amount,
            description: description,
            timestamp: new Date().toISOString(),
            balance: this.config.mining_wallet.balance
        };

        this.config.transaction_history.push(transaction);
        
        // Keep only last 100 transactions
        if (this.config.transaction_history.length > 100) {
            this.config.transaction_history = this.config.transaction_history.slice(-100);
        }
    }

    // Set wallet address
    setWalletAddress(address) {
        this.config.mining_wallet.wallet_address = address;
        this.saveConfig();
        console.log('Wallet address updated:', address);
        return true;
    }

    // Get wallet info
    getWalletInfo() {
        return {
            balance: this.config.mining_wallet.balance,
            wallet_address: this.config.mining_wallet.wallet_address,
            is_active: this.isActive,
            mining_rate: this.config.mining_wallet.mining_rate,
            total_mined: this.config.mining_stats.total_mined,
            active_minutes: this.config.mining_stats.active_minutes
        };
    }

    // Withdraw funds
    withdraw(amount, targetAddress = null) {
        if (amount > this.config.mining_wallet.balance) {
            console.error('Insufficient balance');
            return false;
        }

        this.config.mining_wallet.balance -= amount;
        this.config.mining_stats.total_withdrawals += amount;
        
        const address = targetAddress || this.config.mining_wallet.wallet_address;
        this.addTransaction('withdrawal', amount, `Withdrawal to ${address}`);
        
        this.saveConfig();
        console.log(`Withdrew £${amount.toFixed(2)} to ${address}`);
        return true;
    }

    // Check and execute auto-withdrawal
    checkAutoWithdrawal() {
        const autoWithdrawal = this.config.mining_wallet.auto_withdrawal;
        
        if (autoWithdrawal.enabled && 
            this.config.mining_wallet.balance >= autoWithdrawal.threshold &&
            autoWithdrawal.target_address) {
            
            const withdrawalAmount = this.config.mining_wallet.balance - 100; // Keep £100
            if (withdrawalAmount > 0) {
                this.withdraw(withdrawalAmount, autoWithdrawal.target_address);
            }
        }
    }

    // Set auto-withdrawal settings
    setAutoWithdrawal(enabled, threshold, targetAddress) {
        this.config.mining_wallet.auto_withdrawal = {
            enabled: enabled,
            threshold: threshold,
            target_address: targetAddress
        };
        this.saveConfig();
        console.log('Auto-withdrawal settings updated');
        return true;
    }

    // Get transaction history
    getTransactionHistory(limit = 10) {
        return this.config.transaction_history.slice(-limit).reverse();
    }

    // Get mining statistics
    getMiningStats() {
        return {
            total_mined: this.config.mining_stats.total_mined,
            total_withdrawals: this.config.mining_stats.total_withdrawals,
            start_date: this.config.mining_stats.start_date,
            active_minutes: this.config.mining_stats.active_minutes,
            current_balance: this.config.mining_wallet.balance
        };
    }

    // Reset mining wallet
    resetWallet() {
        this.stopMining();
        this.config = this.getDefaultConfig();
        this.saveConfig();
        console.log('Mining wallet reset');
        return true;
    }

    // Export wallet data
    exportWalletData() {
        return JSON.stringify(this.config, null, 2);
    }
}

// Export for Node.js environment
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MiningWalletManager;
}